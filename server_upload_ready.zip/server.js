import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { searchWeb } from './services/search.js';
import { extractFromPages } from './services/scrape.js';
import { translatePair } from './services/translate.js';
import { normalizeQuery, detectType, uniqByKey } from './utils/text.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'Trust Kikaku Part Finder', time: new Date().toISOString() });
});

app.get('/api/search', async (req, res) => {
  try {
    const qRaw = (req.query.q || '').toString().trim();
    const mode = (req.query.mode || 'auto').toString();
    if (!qRaw) return res.status(400).json({ error: 'Missing q' });

    const q = normalizeQuery(qRaw);
    const inferred = mode === 'auto' ? detectType(q) : mode; // 'number' or 'name'

    const searchResults = await searchWeb(q, inferred);

    const extracted = await extractFromPages(searchResults, { query: q, mode: inferred });

    let enriched = extracted;
    for (const item of enriched) {
      if (!item.enName && item.jaName && item.jaName.length < 100) {
        const t = await translatePair(item.jaName, 'ja');
        item.enName = t.en;
      } else if (!item.jaName && item.enName && item.enName.length < 100) {
        const t = await translatePair(item.enName, 'en');
        item.jaName = t.ja;
      }
    }

    const unique = uniqByKey(enriched, x => `${x.partNumber || ''}|${x.enName || ''}|${x.jaName || ''}`)
      .map((x, i) => ({ rank: i + 1, ...x }));

    res.json({ mode: inferred, query: q, results: unique.slice(0, 30) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Search failed', details: err.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
