import stringSimilarity from 'string-similarity';

export function normalizeQuery(q) {
  return q.trim();
}

export function detectType(q) {
  if (/^[A-Za-z0-9\-_]{5,}$/.test(q) && /\d/.test(q)) return 'number';
  return 'name';
}

export function extractPartNumbers(text, query) {
  const candidates = new Set();
  const re = /\b[A-Z0-9][A-Z0-9\-_.]{4,}\b/gi;
  let m;
  while ((m = re.exec(text)) !== null) {
    const token = m[0].toUpperCase();
    if (token.length <= 35) candidates.add(token);
  }
  const arr = Array.from(candidates);
  const scored = arr.map(s => ({ s, score: stringSimilarity.compareTwoStrings(s, (query || '').toUpperCase()) }))
    .sort((a, b) => b.score - a.score)
    .map(x => x.s);
  return scored;
}

export function guessLanguage(s) {
  if (/[\u3040-\u30ff\u4e00-\u9faf]/.test(s)) return 'ja';
  return 'en';
}

export function cleanName(s) {
  return s.replace(/\s{2,}/g, ' ').replace(/[|»›].*$/,'').trim();
}

export function uniqByKey(arr, fn) {
  const seen = new Set();
  const out = [];
  for (const it of arr) {
    const k = fn(it);
    if (!seen.has(k)) { seen.add(k); out.push(it); }
  }
  return out;
}
